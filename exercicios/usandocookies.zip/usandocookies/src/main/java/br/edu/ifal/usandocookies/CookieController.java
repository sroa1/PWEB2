package br.edu.ifal.usandocookies;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class CookieController {

    @GetMapping("/")
    public String readCookie(@CookieValue(value = "username", defaultValue = "Sem") String username) {
        if(username.equals("Sem")){
            return "Faça seu cadastro";
        }
        return "Bem vindo de volta " + username;
    }

    @GetMapping("/cadastro")
    public ModelAndView cadastro() {
        ModelAndView mv = new ModelAndView("form.html");
        return mv;
    }

    @GetMapping("/change-username")
    public String setCookie(HttpServletResponse response, String name) {
        Cookie cookie = new Cookie("username", name);
        response.addCookie(cookie);
        return "Username is changed!";
    }
}