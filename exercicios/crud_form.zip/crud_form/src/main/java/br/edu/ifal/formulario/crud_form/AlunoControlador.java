package br.edu.ifal.formulario.crud_form;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class AlunoControlador {

    @Autowired
    AlunoRepositorio repo;

    @RequestMapping("/aluno/formulario")
    public ModelAndView formulario(){
        ModelAndView mv = new ModelAndView("formulario.html");
        mv.addObject("aluno", new Aluno());
        return mv;
    }

    @RequestMapping("/aluno/cadastrar")
    public ModelAndView cadastrar(Aluno novoAluno){
        repo.save(novoAluno);
        return new ModelAndView("redirect:/aluno/listar");
    }

    @RequestMapping("/aluno/listar")
    public ModelAndView listar(){
        ModelAndView lista = new ModelAndView("listadealunos.html");
        return lista;
    }
    
}