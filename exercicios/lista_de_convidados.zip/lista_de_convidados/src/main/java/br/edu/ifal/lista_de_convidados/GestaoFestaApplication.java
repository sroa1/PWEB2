package br.edu.ifal.lista_de_convidados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoFestaApplication {

    public static void main(String[] args){
        SpringApplication.run(GestaoFestaApplication.class, args);
    }
}