insert into convidado (id, nome, quantidade_de_acompanhantes)
    values(1, 'Pedro', 2);
insert into convidado (id, nome, quantidade_de_acompanhantes)
    values(2, 'Maria', 3);
insert into convidado (id, nome, quantidade_de_acompanhantes)
    values(3, 'Ricardo', 1);