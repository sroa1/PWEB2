package br.edu.ifal.lista_de_convidados.reporitory;

import org.springframework.data.jpa.repository.JpaRepository;

import br.edu.ifal.lista_de_convidados.model.Convidado;

public interface Convidados extends JpaRepository<Convidado, Long>{

    
}