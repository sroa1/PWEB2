package br.com.democracia.democraciaocinema;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class Controlador{

    @RequestMapping("/formulario")
    public ModelAndView formulario() {
        return new ModelAndView("formulario.html");
    }
    
    @RequestMapping("/resultado")
    public ModelAndView resultado(String nome, String senha){
        String novoNome = nome.replaceAll(" ", "");
        String novaSenha = senha.replaceAll(" ", "");

        ModelAndView mv = new ModelAndView("resultado.html");
        mv.addObject("info", "Seu nome tem: " + novoNome.length() + 
            " letras e sua senha tem: " + novaSenha.length());

        if (novoNome.equals("") || novaSenha.equals("")) {
            ModelAndView mj = new ModelAndView("formulario.html");
            mj.addObject("erro1","Os dois campos são obrigatórios");
            return mj;
        }

        if(novaSenha.length() < 6){
            ModelAndView ms = new ModelAndView("formulario.html");
            ms.addObject("erro2", "A senha não deve conter espaços e deve ter no mínimo 6 caracteres");
            return ms;
        }
        
        return mv;
        
    }

}